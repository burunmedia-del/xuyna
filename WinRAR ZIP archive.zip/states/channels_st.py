from aiogram.filters.state import State, StatesGroup

class new_ch(StatesGroup):
    post = State()