import asyncio
import json
import logging
import aiohttp
from datetime import datetime, timezone
from data.config import MYSQL_host, MYSQL_user, MYSQL_password, MYSQL_database, BASE_WEBHOOK_URL, WEBHOOK_PATH
WEBHOOK_SECRET = 'my-secret'
from data.database import Database

# Настройка логирования
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Инициализация базы данных
try:
    db = Database()
    logger.info("Database initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize database: {e}")
    raise

async def get_active_links():
    """Получает активные ссылки и соответствующие chat_id, bot_id из базы данных."""
    try:
        db.ensure_connection()
        links = db.get_all_actual_crm_links()
        if not links:
            logger.warning("No active links found in crm_links")
            return []
        result = []
        for link in links:
            element = db.get_element(link['element1_id']) or db.get_element(link['element2_id'])
            if element and 'channel_id' in element and 'bot_id' in element:
                result.append({**link, 'chat_id': element['channel_id'], 'bot_id': element['bot_id']})
            else:
                logger.warning(f"No valid element found for link ID {link['id']}")
        logger.info(f"Fetched {len(result)} active links with chat_id and bot_id")
        return result
    except Exception as e:
        logger.error(f"Error fetching links: {e}")
        return []

async def send_webhook(invite_link, chat_id, bot_id):
    """Отправляет вебхук на основной сервер."""
    data = {
        "update_id": int(1000000 * asyncio.get_event_loop().time()),
        "chat_join_request": {
            "chat": {
                "id": int(chat_id),
                "type": "channel",
                "title": "Test Channel",
                "username": None,
                "first_name": None,
                "last_name": None
            },
            "from": {
                "id": 6617138756,
                "is_bot": False,
                "first_name": "N1K_LL",
                "last_name": None,
                "username": "nnklllllllll",
                "language_code": "ru"
            },
            "user_chat_id": 6617138756,
            "date": int(datetime.now(timezone.utc).timestamp()),
            "bio": None,
            "invite_link": {
                "invite_link": invite_link,
                "creator": {
                    "id": bot_id,
                    "is_bot": True,
                    "first_name": "TestBot",
                    "last_name": None,
                    "username": None,
                    "language_code": None
                },
                "creates_join_request": True,
                "is_primary": False,
                "is_revoked": False,
                "name": None,
                "expire_date": None,
                "member_limit": None,
                "pending_join_request_count": None,
                "subscription_period": None,
                "subscription_price": None
            }
        }
    }
    try:
        async with aiohttp.ClientSession() as session:
            headers = {'X-Telegram-Bot-Api-Secret-Token': WEBHOOK_SECRET}
            webhook_url = f"{BASE_WEBHOOK_URL}{WEBHOOK_PATH}"
            logger.info(f"Sending webhook to {webhook_url} with data: {data}")
            async with session.post(webhook_url, json=data, headers=headers) as response:
                if response.status != 200:
                    error_text = await response.text()
                    logger.error(f"Webhook failed with status {response.status}: {error_text}")
                    return f"Error: Webhook failed with status {response.status}: {error_text}"
                result = await response.json()
                logger.info(f"Webhook sent successfully: {result}")
                return f"Success: {json.dumps(result, indent=2)}"
    except Exception as e:
        logger.error(f"Error sending webhook: {e}")
        return f"Error: {str(e)}"

async def main():
    """Основная функция для консольного теста."""
    while True:
        # Получаем активные ссылки
        links = await get_active_links()
        if not links:
            print("No active links found in crm_links. Exiting.")
            break

        # Выводим список ссылок
        print("\nAvailable active links:")
        for i, link in enumerate(links, 1):
            print(f"{i}. ID: {link['id']}, Link: {link['link']}, Chat ID: {link['chat_id']}, Bot ID: {link['bot_id']}")

        # Запрашиваем выбор ссылки по номеру в списке
        try:
            choice = input("\nEnter the number of the link to use (1, 2, 3, etc., or 'q' to quit): ")
            if choice.lower() == 'q':
                break
            choice = int(choice)
            if not (1 <= choice <= len(links)):
                print("Invalid choice. Enter a number corresponding to a link in the list.")
                continue
            selected_link = links[choice - 1]
            invite_link = selected_link['link']
            chat_id = selected_link['chat_id']
            bot_id = selected_link['bot_id']
        except ValueError:
            print("Invalid input. Enter a number or 'q'.")
            continue

        # Отправляем вебхук
        result = await send_webhook(invite_link, chat_id, bot_id)
        print(f"\nResult:\n{result}")

if __name__ == "__main__":
    asyncio.run(main())