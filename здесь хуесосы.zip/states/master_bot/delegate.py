# - *- coding: utf- 8 - *-
from aiogram.fsm.state import State, StatesGroup


class delegate_state(StatesGroup):
    id = State()
