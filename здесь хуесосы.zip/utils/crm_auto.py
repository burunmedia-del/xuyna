from data.database import Database
import uuid
from .channels import create_link_in_channel
from random import choice
from aiogram import Bot
from data.config import BOT_TOKEN

import datetime
import time
import traceback
import json
import os

bot = Bot(token=BOT_TOKEN)
db = Database()

LOGS_DIR = "logs"

def _ensure_logs_dir():
    os.makedirs(LOGS_DIR, exist_ok=True)

def _log_file_path(ts: datetime.datetime | None = None) -> str:
    if ts is None:
        ts = datetime.datetime.now()
    return os.path.join(LOGS_DIR, f"change_privet_{ts.strftime('%Y-%m-%d')}.txt")

def _write_log_line(text: str, ts: datetime.datetime | None = None):
    _ensure_logs_dir()
    path = _log_file_path(ts)
    with open(path, "a", encoding="utf-8") as f:
        f.write(text + "\n")

def log_change_privet(message: str, trace_id: str, **extra):
    now = datetime.datetime.now()
    ts_str = now.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
    base = f"{ts_str} | trace={trace_id} | {message}"
    if extra:
        kv = " ".join(f"{k}={repr(v)}" for k, v in extra.items())
        base = f"{base} | {kv}"
    _write_log_line(base, now)

    json_record = {
        "ts": ts_str,
        "trace": trace_id,
        "msg": message,
        **extra
    }
    _write_log_line(json.dumps(json_record, ensure_ascii=False), now)

class StepTimer:
    def __init__(self, name: str, trace_id: str):
        self.name = name
        self.trace_id = trace_id
        self.t0 = None
    def __enter__(self):
        self.t0 = time.perf_counter()
        return self
    def __exit__(self, exc_type, exc, tb):
        dt = (time.perf_counter() - self.t0) * 1000.0
        if exc:
            log_change_privet(
                f"Шаг '{self.name}' завершился ОШИБКОЙ",
                self.trace_id,
                duration_ms=round(dt, 2),
                error=str(exc)
            )
        else:
            log_change_privet(
                f"Шаг '{self.name}' выполнен",
                self.trace_id,
                duration_ms=round(dt, 2)
            )

async def change_privet(link):
    trace_id = str(uuid.uuid4())
    log_change_privet("Запуск change_privet", trace_id, link_summary={k: link.get(k) for k in ("id","name","chain_id","element1_position","element2_position","privet_id")})

    required_keys = ["chain_id", "element2_id", "element1_position", "element2_position", "id", "name", "privet_id"]
    missing = [k for k in required_keys if k not in link]
    if missing:
        log_change_privet("Отсутствуют обязательные ключи в link", trace_id, missing=missing)
        raise KeyError(f"change_privet: missing keys in link: {missing}")

    try:
        with StepTimer("Получение chain", trace_id):
            chain = db.get_chain(link["chain_id"])
        log_change_privet("Получена chain", trace_id, chain_id=chain.get("id"), pull_id=chain.get("pull_id"))

        with StepTimer("Получение element (element2)", trace_id):
            element = db.get_element(link["element2_id"])
        log_change_privet("Получен element", trace_id, element_id=element.get("id"), channel_id=element.get("channel_id"))

        with StepTimer("Сбор used_privets", trace_id):
            used_privets = [
                x["privet_id"]
                for x in db.get_links_by_chain_and_positions(
                    link["chain_id"],
                    link["element1_position"],
                    link["element2_position"],
                )
            ]
        log_change_privet("Собраны used_privets", trace_id, count=len(used_privets), sample=used_privets[:10])

        with StepTimer("Сбор not_available", trace_id):
            not_available = [
                x["privet_id"]
                for x in db.get_all_actual_crm_links_by_chain_id(link["chain_id"])
            ]
        log_change_privet("Собраны not_available", trace_id, count=len(not_available), sample=not_available[:10])

        cant_use = set(used_privets + not_available)
        log_change_privet("Собран cant_use", trace_id, count=len(cant_use))

        with StepTimer("Получение all_privets из пула", trace_id):
            all_privets = [p["id"] for p in db.get_privets(chain["pull_id"])]
        log_change_privet("Получены all_privets", trace_id, count=len(all_privets), sample=all_privets[:10])

        can_use = [p for p in all_privets if p not in cant_use]
        log_change_privet("Посчитан can_use", trace_id, count=len(can_use), sample=can_use[:10])

        if can_use:
            new_privet = choice(can_use)
            log_change_privet("Выбрана свободная приветка", trace_id, new_privet=new_privet)
        else:
            log_change_privet("Свободных нет — ищем лучшую по конверсии", trace_id)
            best_privet, best_conv = None, -1.0
            with StepTimer("Перебор приветов для конверсии", trace_id):
                for pid in all_privets:
                    stat = db.get_conversion_for_privet(
                        chain_id=chain["id"],
                        element1_position=link["element1_position"],
                        element2_position=link["element2_position"],
                        privet_id=pid,
                    )
                    conv = stat.get("conversion")
                    log_change_privet("Проверка конверсии", trace_id, privet_id=pid, conversion=conv)
                    if conv is not None and (best_privet is None or conv > best_conv):
                        best_conv, best_privet = conv, pid
                        log_change_privet("Новый лидер по конверсии", trace_id, privet_id=best_privet, conversion=best_conv)
            new_privet = best_privet if best_privet is not None else (all_privets[0] if all_privets else None)
            log_change_privet("Выбор приветки при отсутствии свободных", trace_id, chosen=new_privet)
            with StepTimer("Отключение авто-режима для элемента", trace_id):
                db.disable_element_auto(element["id"])
            log_change_privet("Авто-режим отключён", trace_id, element_id=element["id"])

        if new_privet is None:
            log_change_privet("FATAL: не удалось выбрать ни одну приветку", trace_id)
            raise RuntimeError("Нет доступных приветов для выбора")

        with StepTimer("Пометка старой ссылки как неактуальной", trace_id):
            db.set_link_actual_false_by_id(link["id"])
        log_change_privet("Старая ссылка помечена неактуальной", trace_id, link_id=link["id"])

        with StepTimer("Создание новой ссылки в канале", trace_id):
            new_link = await create_link_in_channel(
                element["channel_id"],
                link["name"],
            )
        log_change_privet("Создана новая ссылка", trace_id, new_link=new_link)

        with StepTimer("Получение prev_pair", trace_id):
            prev_pair = db.get_links_by_chain_and_positions_actual(
                chain["id"],
                link["element1_position"] - 1,
                link["element2_position"] - 1,
            )
        prev_id = prev_pair["id"] if prev_pair else 0
        log_change_privet("Определён prev_id", trace_id, prev_id=prev_id)

        with StepTimer("Добавление новой CRM-ссылки в БД", trace_id):
            db.add_crm_link(
                link["name"],
                new_link,
                link["element1_id"],
                link["element2_id"],
                link["element1_position"],
                link["element2_position"],
                chain["id"],
                new_privet,
                0,
                link["privet_id"],
                True,
                prev_id,
            )
        log_change_privet("Новая CRM-ссылка добавлена", trace_id, chain_id=chain["id"], new_privet=new_privet, prev_id=prev_id)

        log_change_privet("Успешное завершение change_privet", trace_id)

    except Exception as e:
        tb = traceback.format_exc()
        log_change_privet("ОШИБКА в change_privet", trace_id, error=str(e), traceback=tb)
        raise
