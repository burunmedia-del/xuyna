from aiogram import Bot, Dispatcher, Router, types
from aiogram.types import Message, CallbackQuery, ChatJoinRequest
from aiogram.filters import CommandStart, Command
import re
from aiogram.utils.token import validate_token
from aiogram.utils.token import TokenValidationError
from data.config import BASE_WEBHOOK_URL, FOR_OTHER_BOTS
from keyboards import *
from aiogram.fsm.context import FSMContext
from filters.start_filters import *
from data.database import Database
from utils.keyboards import build_privet_keyboard, build_last_privet_keyboard
from utils.channels import create_link_in_channel
from utils.crm_auto import change_privet
from utils.channels_u import get_requests_count

from random import choice
import uuid
import os
import json
from datetime import datetime

router = Router()
db = Database()

def _ensure_logs_dir():
    os.makedirs("logs", exist_ok=True)

def _log_event(event: str, **payload):
    _ensure_logs_dir()
    now = datetime.now()
    path = os.path.join("logs", f"{now.strftime('%Y-%m-%d')}.txt")
    record = {"ts": now.isoformat(timespec="seconds"), "event": event, **payload}
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

@router.chat_join_request()
async def request_handler(update: ChatJoinRequest, bot: Bot):
    try:
        RC = int(db.get_config_value('RC'))
        update_link_full = update.invite_link.invite_link if update.invite_link else None
        update_link_name = update.invite_link.name if update.invite_link else None
        update_link_requests = 1  # Фиксированное значение вместо pending_join_request_count
        update_channel_id = update.chat.id
        update_user_id = update.from_user.id

        _log_event(
            "join_request_received",
            user_id=update_user_id,
            chat_id=update_channel_id,
            link=update_link_full,
            link_name=update_link_name,
            link_requests=update_link_requests,
            rc=RC
        )

        element_by_chat_id = db.get_element_by_channel_id(update_channel_id)
        if element_by_chat_id is None:
            _log_event("no_element_for_channel", chat_id=update_channel_id)
            return

        sort = sorted(db.get_elements(element_by_chat_id['chain_id']), key=lambda x: x['queue'])
        if sort[-1] == element_by_chat_id:
            chain = db.get_chain(element_by_chat_id['chain_id'])
            if chain['last_element_privet'] is not None:
                last_privet = eval(chain['last_element_privet'])
                last_privet_text = last_privet['text']
                last_privet_keyboard = build_last_privet_keyboard(last_privet['keyboard'])
                _log_event(
                    "send_last_privet",
                    user_id=update_user_id,
                    chat_id=update_channel_id,
                    chain_id=element_by_chat_id['chain_id']
                )
                await bot.send_message(
                    chat_id=update_user_id,
                    text=last_privet_text,
                    reply_markup=last_privet_keyboard,
                    parse_mode="HTML"
                )
                return

        if element_by_chat_id['main']:
            next_link = db.get_links_by_chain_and_positions_actual(element_by_chat_id['chain_id'], 1, 2)
            last_change_requests = element_by_chat_id['last_change_requests']
            requests_in_main_channel_now = await get_requests_count(update_channel_id)

            _log_event(
                "main_channel_state",
                chat_id=update_channel_id,
                chain_id=element_by_chat_id['chain_id'],
                last_change_requests=last_change_requests,
                requests_now=requests_in_main_channel_now,
                threshold_rc=RC,
                auto=bool(element_by_chat_id['auto']),
                next_link_id=next_link['id'] if next_link else None
            )

            if requests_in_main_channel_now - last_change_requests >= RC:
                _log_event(
                    "rc_exceeded_main",
                    delta=requests_in_main_channel_now - last_change_requests
                )
                if element_by_chat_id['auto'] and next_link:
                    await change_privet(next_link)
                    db.update_element_last_change_requests(element_by_chat_id['id'], requests_in_main_channel_now)
                    _log_event(
                        "privet_changed_main",
                        element_id=element_by_chat_id['id'],
                        new_last_change_requests=requests_in_main_channel_now,
                        next_link_id=next_link['id']
                    )
                elif not element_by_chat_id['auto'] and next_link:
                    better_id = find_better_privet_id(element_by_chat_id['chain_id'], chain['pull_id'], 1, 2, 5)
                    if better_id:
                        _log_event(
                            "privet_changed_better_conversion",
                            element_id=element_by_chat_id['id'],
                            old_privet_id=next_link['privet_id'],
                            new_privet_id=better_id,
                            reason="better_conversion"
                        )
                        await change_privet(next_link, new_privet_id=better_id)
                        db.update_element_last_change_requests(element_by_chat_id['id'], requests_in_main_channel_now)

            if next_link:
                next_link_privet = db.get_privet_by_id(next_link['privet_id'])
                text_for_send = next_link_privet['text']
                keyboard_for_attach = build_privet_keyboard(next_link_privet['keyboard'], next_link['link'])
                _log_event(
                    "send_next_privet_main",
                    user_id=update_user_id,
                    chat_id=update_channel_id,
                    next_link_id=next_link['id']
                )
                await bot.send_message(
                    chat_id=update_user_id,
                    text=text_for_send,
                    reply_markup=keyboard_for_attach,
                    parse_mode='HTML'
                )
            return

        link = None
        if update_link_full:
            link = db.get_link_by_partial_link(update_link_full[:-3])

        if link is None:
            _log_event(
                "no_link_for_partial",
                chat_id=update_channel_id,
                link_partial=update_link_full[:-3] if update_link_full else None
            )
            return

        next_link = db.get_links_by_chain_and_positions_actual(
            element_by_chat_id['chain_id'],
            link['element2_position'],
            link['element2_position'] + 1
        )

        _log_event(
            "non_main_flow_state",
            chat_id=update_channel_id,
            chain_id=element_by_chat_id['chain_id'],
            current_link_id=link['id'],
            current_link_requests=link['requests'],
            update_link_requests=update_link_requests,
            threshold_rc=RC,
            auto=bool(element_by_chat_id['auto']),
            next_link_id=next_link['id'] if next_link else None
        )

        if update_link_requests is not None and update_link_requests > link['requests']:
            db.update_crm_link_requests(link['id'], update_link_requests)
            _log_event(
                "link_requests_updated",
                link_id=link['id'],
                new_requests=update_link_requests
            )
            if update_link_requests >= RC and element_by_chat_id['auto'] and next_link:
                await change_privet(next_link)
                _log_event(
                    "privet_changed_non_main",
                    element_id=element_by_chat_id['id'],
                    next_link_id=next_link['id']
                )
            elif update_link_requests >= RC and not element_by_chat_id['auto'] and next_link:
                better_id = find_better_privet_id(element_by_chat_id['chain_id'], chain['pull_id'], link['element2_position'], link['element2_position'] + 1, 5)
                if better_id:
                    _log_event(
                        "privet_changed_better_conversion",
                        element_id=element_by_chat_id['id'],
                        old_privet_id=next_link['privet_id'],
                        new_privet_id=better_id,
                        reason="better_conversion"
                    )
                    await change_privet(next_link, new_privet_id=better_id)

        if next_link:
            next_link_privet = db.get_privet_by_id(next_link['privet_id'])
            text_for_send = next_link_privet['text']
            keyboard_for_attach = build_privet_keyboard(next_link_privet['keyboard'], next_link['link'])
            _log_event(
                "send_next_privet_non_main",
                user_id=update_user_id,
                chat_id=update_channel_id,
                next_link_id=next_link['id']
            )
            await bot.send_message(
                chat_id=update_user_id,
                text=text_for_send,
                reply_markup=keyboard_for_attach,
                parse_mode='HTML'
            )

    except Exception as e:
        _log_event("error", error=str(e), chat_id=update.chat.id if update and update.chat else None)
        raise



import logging
import uuid
from random import choice
from data.database import Database

logger = logging.getLogger(__name__)
db = Database()

def _log_event(event: str, **payload):
    """Логирование событий (копия из вашего кода для совместимости)."""
    os.makedirs("logs", exist_ok=True)
    now = datetime.datetime.now()
    path = os.path.join("logs", f"{now.strftime('%Y-%m-%d')}.txt")
    record = {"ts": now.isoformat(timespec="seconds"), "event": event, **payload}
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

def get_conversion_for_privet(link, previous_requests=0):
    """Рассчитывает конверсию для указанной ссылки (копия из вашего кода)."""
    current_requests = link['requests']
    if previous_requests == 0:
        if not link['previous_pair']:
            _log_event("conversion_error", link_id=link['id'], note="Нет previous_pair")
            return {"link_id": link['id'], "conversion": None, "note": "Нет previous_pair"}
        previous = db.get_crm_link_by_id(link['previous_pair'])
        if not previous:
            _log_event("conversion_error", link_id=link['id'], previous_id=link['previous_pair'],
                       error="Previous link not found")
            return {"link_id": link['id'], "conversion": None,
                    "note": f"Previous link {link['previous_pair']} not found"}
        prev_requests = previous['requests']
        conversion = round((current_requests / prev_requests) * 100, 2) if prev_requests > 0 else 0
        _log_event("conversion_calculated", link_id=link['id'], current_requests=current_requests,
                   previous_requests=prev_requests, conversion=conversion, mode="previous_pair")
        return {
            "link_id": link['id'],
            "current_requests": current_requests,
            "previous_requests": prev_requests,
            "conversion": conversion,
            "mode": "previous_pair"
        }
    else:
        prev_requests = previous_requests
        conversion = round((current_requests / prev_requests) * 100, 2) if prev_requests > 0 else 0
        _log_event("conversion_calculated", link_id=link['id'], current_requests=current_requests,
                   previous_requests=prev_requests, conversion=conversion, mode="provided_requests")
        return {
            "link_id": link['id'],
            "current_requests": current_requests,
            "previous_requests": prev_requests,
            "conversion": conversion,
            "mode": "provided_requests"
        }

def get_used_privet_ids_for_pair(chain_id, element1_position, element2_position):
    """Получает ID всех приветок, использованных для данной пары позиций."""
    links = db.get_links_by_chain_and_positions(chain_id, element1_position, element2_position)
    return {link['privet_id'] for link in links}

def get_next_free_privet_id(chain_id, pull_id, element1_position, element2_position):
    """Находит ID следующей свободной приветки из пула."""
    all_privets = db.get_privets(pull_id)
    used = get_used_privet_ids_for_pair(chain_id, element1_position, element2_position)
    active = db.get_active_privet_ids(chain_id)
    free = [p['id'] for p in all_privets if p['id'] not in used and p['id'] not in active]
    return choice(free) if free else None

async def change_privet(link, new_privet_id=None):
    """Меняет приветку для указанной ссылки, создавая новые ссылки для текущего и предыдущего звеньев."""
    chain_id = link['chain_id']
    element1_position = link['element1_position']
    element2_position = link['element2_position']
    old_privet_id = link['privet_id']

    # Деактивируем текущую ссылку
    db.set_link_actual_false_by_id(link['id'])
    element1 = db.get_element(link['element1_id'])
    element2 = db.get_element(link['element2_id'])

    # Создаём новую ссылку для текущего канала (element2) с той же приветкой
    new_link_url = await create_link_in_channel(element2['channel_id'], f"link_{uuid.uuid4().hex}")

    # Определяем previous_pair
    prev_pos1 = element1_position - 1
    previous_pair = 0
    if prev_pos1 >= 1:
        prev_pos2 = element1_position
        prev_link = db.get_links_by_chain_and_positions_actual(chain_id, prev_pos1, prev_pos2)
        if prev_link:
            # Создаём новую ссылку для предыдущего канала с новой приветкой
            prev_element1 = db.get_element(prev_link['element1_id'])
            prev_element2 = db.get_element(prev_link['element2_id'])
            new_prev_link_url = await create_link_in_channel(prev_element2['channel_id'], f"link_{uuid.uuid4().hex}")
            db.set_link_actual_false_by_id(prev_link['id'])

            # Выбираем новую приветку, если не указана
            privet_id_to_use = new_privet_id
            if not privet_id_to_use:
                chain = db.get_chain(chain_id)
                pull_id = chain['pull_id']
                privet_id_to_use = get_next_free_privet_id(chain_id, pull_id, prev_pos1, prev_pos2)
                if not privet_id_to_use:
                    privet_id_to_use = get_best_privet_id_for_pair(chain_id, pull_id, prev_pos1, prev_pos2)

            if privet_id_to_use:
                db.add_crm_link(
                    name=prev_link['name'],
                    link=new_prev_link_url,
                    element1_id=prev_link['element1_id'],
                    element2_id=prev_link['element2_id'],
                    element1_position=prev_pos1,
                    element2_position=prev_pos2,
                    chain_id=chain_id,
                    privet_id=privet_id_to_use,
                    requests=0,
                    actual=True
                )
                new_prev_link = db.get_links_by_chain_and_positions_actual(chain_id, prev_pos1, prev_pos2)
                previous_pair = new_prev_link['id'] if new_prev_link else 0
                _log_event(
                    "new_link_created_prev",
                    chain_id=chain_id,
                    element1_position=prev_pos1,
                    element2_position=prev_pos2,
                    link_id=new_prev_link['id'] if new_prev_link else None,
                    privet_id=privet_id_to_use
                )

    # Создаём новую ссылку для текущего канала
    requests = link['requests'] if new_privet_id == old_privet_id else 0
    db.add_crm_link(
        name=link['name'],
        link=new_link_url,
        element1_id=link['element1_id'],
        element2_id=link['element2_id'],
        element1_position=element1_position,
        element2_position=element2_position,
        chain_id=chain_id,
        privet_id=old_privet_id,
        requests=0,
        actual=True,
        previous_pair=previous_pair
    )
    _log_event(
        "new_link_created_current",
        chain_id=chain_id,
        element1_position=element1_position,
        element2_position=element2_position,
        link_id=link['id'],
        privet_id=old_privet_id,
        new_link_url=new_link_url
    )

def find_better_privet_id(chain_id, pull_id, element1_position, element2_position, threshold=5):
    """Находит ID приветки, которая на threshold% лучше текущей."""
    current_link = db.get_links_by_chain_and_positions_actual(chain_id, element1_position, element2_position)
    if not current_link:
        _log_event("no_current_link", chain_id=chain_id, element1_position=element1_position, element2_position=element2_position)
        return None

    current_conv = get_conversion_for_privet(current_link).get('conversion')
    if current_conv is None:
        _log_event("no_current_conversion", link_id=current_link['id'])
        return None

    used_privets = get_used_privet_ids_for_pair(chain_id, element1_position, element2_position)
    best_id = None
    best_conv = current_conv

    for pid in used_privets:
        if pid == current_link['privet_id']:
            continue
        privet_link = db.get_crm_link_by_privet_and_positions(chain_id, element1_position, element2_position, pid)
        if not privet_link:
            continue
        conv_info = get_conversion_for_privet(privet_link)
        conv = conv_info.get('conversion')
        if conv is None:
            continue
        if conv > best_conv + threshold:
            best_conv = conv
            best_id = pid

    if best_id:
        _log_event(
            "better_privet_found",
            chain_id=chain_id,
            element1_position=element1_position,
            element2_position=element2_position,
            old_privet_id=current_link['privet_id'],
            new_privet_id=best_id,
            old_conversion=current_conv,
            new_conversion=best_conv
        )
    return best_id

def get_best_privet_id_for_pair(chain_id, pull_id, element1_position, element2_position):
    """Находит ID приветки с лучшей конверсией для данной пары позиций."""
    used_privets = get_used_privet_ids_for_pair(chain_id, element1_position, element2_position)
    if not used_privets:
        _log_event("no_used_privets", chain_id=chain_id, element1_position=element1_position, element2_position=element2_position)
        return None
    best_id = None
    best_conv = -1
    for pid in used_privets:
        link = db.get_crm_link_by_privet_and_positions(chain_id, element1_position, element2_position, pid)
        if not link:
            continue
        conv_info = get_conversion_for_privet(link)
        conv = conv_info.get('conversion')
        if conv is None:
            continue
        if conv > best_conv:
            best_conv = conv
            best_id = pid
    if best_id:
        _log_event(
            "best_privet_found",
            chain_id=chain_id,
            element1_position=element1_position,
            element2_position=element2_position,
            privet_id=best_id,
            conversion=best_conv
        )
    return best_id
